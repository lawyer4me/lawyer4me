
# 💸 Crypto Wallets

These wallets are active and ready for bounty/task payments.

- **TON**: `UQCW1AwmwxwwinFKtnnBx2rfd0GHYoctUGqKGOq2tAWnZ5Xt`
- **Ethereum / MetaMask**: `0x27903b82d45c6e7b19565820194ec67a68f46947`

All payments are logged and confirmed via live agents.
